# zhihuDecrypt

## 欢迎你, 可以给我一颗星星吗? 

用于识别与解密部分文章的Python包

---

## 声明

1. 本项目不提供任何采集知乎内容的方法或技术
2. 仅作学习文本分析用途，请勿用于侵犯他人利益 :)
3. 代码很粗糙，欢迎PR :)
4. 大部分代码没写注释，我懒 :(
5. 本项目在GPLv3下授权，欢迎各位在遵循许可的情况下继续开发

## 用法

1. `git submodule add https://github.com/cxzlw/zhihuDecrypt`
2. `import zhihuDecrypt`
3. 参考 `example.py`

## 推荐网站

### 不对该网站内容负责，请自行评估

[C的云存储](https://cdycc.cn/)

